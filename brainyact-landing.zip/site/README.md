# BrainyAct B2B Landing Page

Static site. Deployed via GitHub Pages.

## Structure

```
index.html                       (must be named exactly this, at repo root)
.nojekyll                        (stops Jekyll from ignoring files)
assets/brainyact-logo.png        (nav, footer, favicon)
assets/hero-brainyact-session.jpg (hero image, OG preview image)
```

The two filenames above are hardcoded in index.html. They must match exactly, including lowercase and hyphens.

## Asset specs

brainyact-logo.png: transparent PNG, roughly 480x102 px (rendered at 160x34, so 3x for retina). Export from the Canva Brand Kit.

hero-brainyact-session.jpg: JPG, roughly 1200x900 px, under 300 KB. This one doubles as the social share preview image, so it should read well as a thumbnail.

## Deploy steps

1. Create a new public repo (example: brainyact-landing).
2. Upload index.html, .nojekyll, and the assets folder to the repo root.
3. Settings, then Pages, then Source: Deploy from a branch, branch main, folder / (root).
4. Wait about a minute. The site publishes at https://USERNAME.github.io/brainyact-landing/

## Custom domain (optional)

index.html sets its canonical URL and OG image to https://brainyact.com/. If this page is going to live at that domain, add a file named CNAME at the repo root containing one line: brainyact.com. Then point the DNS A records at GitHub Pages and enable Enforce HTTPS in Settings, Pages.

If it is NOT going to live at brainyact.com, update the canonical link and the og:image meta tag in index.html to the real URL, otherwise link previews will break.
